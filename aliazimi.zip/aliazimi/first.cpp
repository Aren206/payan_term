#include <iostream>
#include <ctime>
#include<windows.h>
using namespace std;
// Rand func
void gr(int arr[], int n) {
    for (int i = 1; i <= n; ++i) {
        arr[i - 1] = i;
    }
    srand(time(0));
    for (int i = n - 1; i > 0; --i) {
        int j = rand() % (i + 1);
        swap(arr[i], arr[j]);
    }
}

int main() {
	lk:
    int n;
    do {
        cout << "(n): ";
        cin >> n;
        if (n <= 0 || n >10) {
            cout << "Error!" << "\n";
        }
    } while (n <= 0 || n > 10);

    int arr[10]; 
    gr(arr, n);

    int ls[10][10] = {0};
    for (int i = 0; i < n; i++) {
        ls[0][i] = arr[i];
    }

    for (int i = 1; i < n; i++) {
        ls[i][0] = ls[i - 1][n - 1];
        for (int j = 1; j < n; j++) {
            ls[i][j] = ls[i - 1][j - 1];
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << ls[i][j] << " ";
        }
        cout << "\n";
    }
    // +++++++++++++++++++++++++++++++++++++++
    Sleep(250); cout << "-+"; Sleep(250); cout  << "-+"; Sleep(250); cout << "-+"; Sleep(250); cout << "-+";cout << "-+"; Sleep(250); cout << "-+";
    cout << "\n";
        int xp;
        int arr2[10]; 
        gr(arr2, n);
        int ls2[10][10] = {0};
        for (int i = 0; i < n; i++) {
            ls2[i][0] = arr2[i];
        }
        for (int i = 0; i < n; i++)
        {
            for (int j = 1; j < n; j++)
            {
                xp = ls2[i][j-1];
                if (xp == n)
                {
                    xp = 0;
                }
                
                xp = xp +1;
                ls2[i][j] = xp;
            }
        }
        for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << ls2[i][j] << " ";
        }
        cout << "\n";
        }     
        // ++++++++++++++++++++++
        cout << "____";
        cout << "\n";
        int opt;
        int op[10][10];
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                op[i][j] = ls[i][j] * 10 + ls2[i][j];
            }
        }

        for (int i = 0; i < n; i++)
        {
            for(int j = 0 ; j < n ; j++){
                for (int p= i; p < n; p++)
                {
                    for (int q= j+1; q < n; q++)
                {
                    if (op[i][j] == op[p][q])
                    {
                        opt = opt +1;
                    }
                    
                }
                }
                
            }
        }
        if(opt == 0){
        	cout << "|YES|";
		}
		else {
			cout << "|NO|";
		}
		  
}
