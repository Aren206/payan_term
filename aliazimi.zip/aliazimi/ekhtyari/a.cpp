#include <iostream>
using namespace std;

const int MAX_SIZE = 10;

bool isValid(int board[MAX_SIZE][MAX_SIZE], int row, int col, int num, int size) {
    for (int i = 0; i < size; ++i) {
        if (board[row][i] == num || board[i][col] == num) {
            return false;
        }
    }


    if (row == col) {
        for (int i = 0; i < size; ++i) {
            if (board[i][i] == num) {
                return false;
            }
        }
    }
    
    if (row + col == size - 1) {
        for (int i = 0; i < size; ++i) {
            if (board[i][size - 1 - i] == num) {
                return false;
            }
        }
    }

    return true;
}

bool solve(int board[MAX_SIZE][MAX_SIZE], int row, int col, int size) {
    
    if (col == size) {
        col = 0;
        row += 1;
    }

    
    if (row == size) {
        return true;
    }

    if (board[row][col] != 0) {
        return solve(board, row, col + 1, size);
    }

 
    for (int num = 1; num <= size; ++num) {
        if (isValid(board, row, col, num, size)) {
            
            board[row][col] = num;
            if (solve(board, row, col + 1, size)) {
                return true;
            }

           
            board[row][col] = 0;
        }
    }

    return false;
}

void printBoard(int board[MAX_SIZE][MAX_SIZE], int size) {
    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j) {
            cout << board[i][j] << " ";
        }
        cout << "\n";
    }
}
void copyBoard(int board[MAX_SIZE][MAX_SIZE],int board2[MAX_SIZE][MAX_SIZE], int n) {
	for(int i =0; i < n ; i++){
	board2[0][i] = board[0][i];
}
for(int i =1; i < n ; i++){
	for(int j = n ; j > 0 ; --j){
		board2[i][j] = board2[i-1][j-1];
	}
}

for(int i =1; i < n ; i++){
	for(int j = 0 ; j < n-1 ; j++){
		board2[i][j] = board2[i-1][j+1];
	}

}

}

int main() {
    int n ;
    cin >> n;
    int board[MAX_SIZE][MAX_SIZE] = {0};
    int board2[MAX_SIZE][MAX_SIZE] = {0};

    if (solve(board, 0, 0, n)) {
        printBoard(board, n);
        cout << "\n";
    } else {
        cout << "No solution exists." << "\n";
    }
		copyBoard(board,board2,n);
		printBoard(board2,n);
		
		
		
		
        int opt;
        int op[10][10];
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                op[i][j] = board[i][j] * 10 + board2[i][j];
            }
        }

        for (int i = 0; i < n; i++)
        {
            for(int j = 0 ; j < n ; j++){
                for (int p= i; p < n; p++)
                {
                    for (int q= j+1; q < n; q++)
                {
                    if (op[i][j] == op[p][q])
                    {
                        opt = opt +1;
                    }
                    
                }
                }
                
            }
        }
        if(opt == 0){
        	cout << "|YES|" << "\n";
		}
		else {
			cout << "|NO|" << "\n";
		}
		printBoard(op,n);
		
    return 0;
}
